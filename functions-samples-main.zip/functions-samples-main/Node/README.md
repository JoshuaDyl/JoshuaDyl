# Node.js (2nd gen) samples

This folder contains examples for 2nd gen Node.js functions. See a description of all samples in this folder in the [root README](../README.md).