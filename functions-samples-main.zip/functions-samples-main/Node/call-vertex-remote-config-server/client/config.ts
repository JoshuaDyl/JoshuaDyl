export const firebaseConfig = {
  YOUR_FIREBASE_CONFIG
};

  // Your ReCAPTCHA Enterprise site key (must be from the same project
  // as the Firebase config above).
export const RECAPTCHA_ENTERPRISE_SITE_KEY =
  "YOUR_RECAPTCHA_KEY";
