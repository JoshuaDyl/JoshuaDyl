---
name: Documentation issue
about: Are a sample's docs incorrect or unclear?
title: '[DOCS] for sample: '
labels: ''
assignees: ''
---

<!-- This is only for issues with the documentation in this repository. -->

### Which sample?

**Sample name or URL** **Link to closest heading**

### What is the issue with this sample's docs?

<!-- Broken link, unclear step, outdated step, etc... -->
