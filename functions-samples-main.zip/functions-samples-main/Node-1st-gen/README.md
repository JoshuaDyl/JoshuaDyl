# Node.js (1st gen) samples

This folder contains examples for 1st gen functions. Note that 2nd gen functions are available and the recommended platform for Cloud Functions for Firebase.

See a description of all samples in this folder in the [root README](../README.md).