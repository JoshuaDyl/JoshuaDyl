# Wipeout user data when account deleted

**This code has moved to its own repo at
https://github.com/firebase/user-data-protection**

(For archeologists, Git history prior to mid October 2017 is here, while
subsequent history is in the new repo.)
